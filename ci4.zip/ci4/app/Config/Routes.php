<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Product::index');

//Route is defined to allow /test to work with the
//controller
$routes->get('/test', 'Home::test');
$routes->get('/service', 'Home::service');
$routes->get('/contact', 'Home::contact');
$routes->get('/submission', 'Home::submission');


$routes->get('/another_test','Service::index');
$routes->get('/list','Service::list');

//listing
$routes->get('/products/(:num)','Product::list/$1');

//adding
$routes->get('/addproduct','Product::add');

//updating
$routes->get('/updateproduct','Product::update');

//delete
$routes->get('/deleteproduct/(:num)','Product::delete/$1');