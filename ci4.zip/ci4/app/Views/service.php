<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
</head>
<body>
    <h1>List of all services</h1>
    <br>

    <div class="list">
        <ul>
        <?php foreach($services as $value):  ?>
            <li><?= $value; ?></li>
        <?php endforeach; ?>
        </ul>        
    </div>

    <br>
    <a href="/another_test">Go back Home</a>
</body>
</html>