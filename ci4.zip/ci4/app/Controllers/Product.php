<?php

namespace App\Controllers;

use App\Models\ProductModel;

class Product extends BaseController
{
    private $product;

    public function __construct()
    {
        $this->product = model('ProductModel');
    }

    public function index(){
        $data['list'] = $this->product->findAll();
        return view('listProduct', $data);
    }

    //list all products that are saved in the database
    //database is products
    public function list($id){
        // $products = new \App\Models\ProductModel();
        
        $results = $this->product->find($id);

        // var_dump($results);

        // echo $results[0]['description'];

        echo $results['description'] . " - " . $results['quantity'] . "kg";
    }

    public function add(){
        //add a new product 

        //description, price, quantity
        $data = [
            "description" => "DragonFruit",
            "price" => 70,
            "quantity" => 5
        ];

        // $products = new \App\Models\ProductModel();

        $var = $this->product->insert($data);

        echo $var;
    }

    public function update(){
       
        $data = [
            "description" => "Grapes",
            "quantity" => 60
        ];

        // $products = new \App\Models\ProductModel();

        $this->product->update(2, $data);
    }

    public function delete($id){
        $this->product->delete($id);
    }
}