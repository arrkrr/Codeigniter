<?php

namespace App\Controllers;

class Service extends BaseController
{
    //the function called index will be found by the server automatically
    public function index(){
        echo "Yes, You are on the right track";
    }

    //the function to list all available services
    public function list(){
        $services = ["Haircut", "Hope", "Shower", "Food", "Bible study"];

        $data['title'] = "Service";
        $data['services'] = $services;     
           
        return view('service', $data);
    }

}