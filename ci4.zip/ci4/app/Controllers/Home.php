<?php

namespace App\Controllers;

class Home extends BaseController
{
    //the function that returns welcome_message.php page
    public function index()
    {
        return view('welcome_message');       
    }

    public function test(){
        echo "This is a test";
    }
}
