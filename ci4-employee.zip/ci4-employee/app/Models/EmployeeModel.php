<?php

namespace App\Models;

use CodeIgniter\Model;

class EmployeeModel extends Model
{
    protected $table = "employees";
    protected $primaryKey = "emp_no";

    protected $return_type = 'array';

    protected $allowedFields = [
        'emp_no', 'birth_date', 'first_name', 'last_name', 'gender', 'hire_date'
    ];
}