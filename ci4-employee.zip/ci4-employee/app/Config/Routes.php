<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Employee::index');
// $routes->get('delete/(:num)', 'Employee::delete/$1');

//used for adding a new employee
$routes->get('/addnew', 'Employee::addnew');
$routes->post('/store', 'Employee::store');

//route for deleting an employee
$routes->get('/delete/(:num)', 'Employee::delete/$1');

//route for updating an employee
$routes->get('/edit/(:num)', 'Employee::edit/$1');
$routes->post('/update/(:num)', 'Employee::update/$1');