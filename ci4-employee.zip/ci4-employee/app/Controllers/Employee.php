<?php

namespace App\Controllers;


class Employee extends BaseController
{
    private $model;
    protected $request;
    public function __construct(){
        //initialization of a model
        $this->model = new \App\Models\EmployeeModel(); 
        // $this->request = $request;
    }
    public function index()
    {
        $data['list_of_employee'] = $this->model->orderBy('emp_no', 'desc')->findAll(150);
        // var_dump($data);

        echo view('partials/header');
        echo view('employee', $data);
        echo view('partials/footer');
    }
    public function edit($id){
        $data['employee'] = $this->model->where('emp_no', $id)->first();
        echo view('partials/header');
        echo view('edit', $data);
        echo view('partials/footer');
        // echo "passed here" . $id;
    }
    public function delete($id){
        $this->model->delete($id);
        return redirect()->to('/');
    }
    public function addnew(){
        echo view('partials/header');
        echo view('add');
        echo view('partials/footer');
    }
    //function to store all data from add.php
    public function store(){
        // $data = [
        //     'emp_no'=> $_POST['employee_id'],
        //     'birth_date' => $_POST['birth_date'],
        //     'first_name' => $_POST['first_name'],
        //     'last_name' => $_POST['last_name'],
        //     'gender' => $_POST['gender'],
        //     'hire_date' => $_POST['hire_date']
        // ];
        $data = [
            'emp_no'=> $this->request->getVar('employee_id'),
            'birth_date' => $this->request->getVar('birth_date'),
            'first_name' => $this->request->getVar('first_name'),
            'last_name' => $this->request->getVar('last_name'),
            'gender' => $this->request->getVar('gender'),
            'hire_date' => $this->request->getVar('hire_date'),
        ];
        // var_dump($data);
        $is_correct = $this->model->insert($data, false);

        if ($is_correct){
            return redirect()->to('/');
        }
    }
    public function update($id){
        $data = [
            'emp_no'=> $id,
            'birth_date' => $this->request->getVar('birth_date'),
            'first_name' => $this->request->getVar('first_name'),
            'last_name' => $this->request->getVar('last_name'),
            'gender' => $this->request->getVar('gender'),
            'hire_date' => $this->request->getVar('hire_date'),
        ];
        // var_dump($data);
        $is_correct = $this->model->update($id, $data);

        if ($is_correct){
            return redirect()->to('/');
        }
    }
}