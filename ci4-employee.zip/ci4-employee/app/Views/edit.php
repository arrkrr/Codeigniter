<form action="/update/<?= $employee['emp_no']?>" method="POST">
  <div class="container">
  <div class="mb-3 col-3">
    <label for="emp_no" class="form-label">Employee ID</label>
    <input type="text" class="form-control" id="employee_id" name="employee_id" value="<?= $employee['emp_no'] ?>" disabled>
  </div>
  <div class="mb-3 col-3">
    <label for="birth date" class="form-label">birth date</label>
    <input type="date" class="form-control" id="birth_date" name="birth_date" value="<?= $employee['birth_date'] ?>" required>
  </div>
  <div class="mb-3 col-3">
    <label for="first name" class="form-label">First Name</label>
    <input type="text" class="form-control" id="first_name" name="first_name" value="<?= $employee['first_name'] ?>" required>
  </div>
  <div class="mb-3 col-3">
    <label for="last name" class="form-label">Last Name</label>
    <input type="text" class="form-control" id="last_name" name="last_name" value="<?= $employee['last_name'] ?>">
  </div>
  <div class="form-check">
  <input class="form-check-input" type="radio" name="gender" value="M" <?php if($employee['gender']=='M') echo "checked"; else echo ""; ?>>
  <label class="form-check-label" for="flexRadioDefault1">
    Male
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="gender" value="F" <?php if($employee['gender']=='F') echo "checked"; else echo ""; ?>>
  <label class="form-check-label" for="flexRadioDefault2">
    Female
  </label>
  <div class="mb-3 col-3">
    <label for="hire date" class="form-label">hire date</label>
    <input type="date" class="form-control" id="hire_date" name="hire_date" value="<?= $employee['hire_date'] ?>">
  </div>
</div>
  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</div>
</form>