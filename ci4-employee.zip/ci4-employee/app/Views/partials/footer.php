</body>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</html>