<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid">
    <h1>List of all employees</h1>
    <br>
    <br>
    <a type="button" class="btn btn-primary mb-3" href="addnew">Add new</a>
    <table class="table table-dark table-striped-columns">
        <thead>
            <tr>
                <th>EMP ID</th>
                <th>Full Name</th>
                <th>Birth Date</th>
                <th>Gender</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($list_of_employee as $employee): ?>
                <tr>
                    <td><?= $employee['emp_no']?></td>
                    <td><?= $employee['first_name'] . ' ' . $employee['last_name']?></td>
                    <td><?= $employee['birth_date']?></td>
                    <td><?= $employee['gender'] == 'M' ? 'Male' : 'Female'; ?></td>
                    <td><a href="/edit/<?= $employee['emp_no'] ?>" class="btn btn-info">Edit</a> | 
                    <button type="button" id="deletebtn" class="btn btn-danger" onclick="deleteemployee(<?= $employee['emp_no'] ?>)">Delete</button></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    </div>

    <script>
        function deleteemployee(id){
            swal({
                title: "Are you sure to delete the employee # " + id + " ?",
                text: "Once deleted, you will not be able to recover this employee!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                })
                .then((willDelete) => {
                if (willDelete) {
                    swal(" The employee has been removed!", {
                    icon: "success",
                    });
                    window.location='/delete/' + id;
                } else {
                    swal("Cancellation successful");
                }
            });
            // result = confirm('Are you sure to delete the employee N# ' + id + '?');

            // if(result){
            //     window.location='/delete/' + id;
            // }
        }
    </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
